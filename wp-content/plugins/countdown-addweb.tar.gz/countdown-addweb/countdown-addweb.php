<?php

/*
  Plugin Name: countdown-addweb Plugin
  Plugin URI: http://localhost/public/wordpress/plugin
  Description: This is my first plugin
  Version: 1.0.0
  Author: Krina
  Author URI: http://localhost/public/wordpress/
  Text Domain: countdown-addweb
 */

//class countdownaddweb_main {
//
//    function __construct() {
//
//        require_once(plugin_dir_path(__FILE__) . 'includes/countdownaddweb-script.php');
//        
//        require_once (plugin_dir_path(__FILE__) . 'admin/class.settings-api.php');
//        require_once (plugin_dir_path(__FILE__) . 'admin/settings.php');
//        new WeDevs_Settings_API_Test();
//    }
//}
//
//$countdownaddweb_main = new countdownaddweb_main();


    //echo plugin_dir_path(__FILE__) . 'admin/settings.php'; die;

require_once (plugin_dir_path(__FILE__) . 'admin/class.settings-api.php');
require_once (plugin_dir_path(__FILE__) . 'admin/settings.php');
new WeDevs_Settings_API_Test();
